<?php

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
require dirname(__DIR__) . '/app/bootstrap.php';
use Learnow\Helpers\Url;
$checks = [];
$cases = [];
$original = getenv('APP_URL');
function verifyUrl(bool $ok, string $name): void
{
    global $checks;
    $checks[] = ['passed' => $ok,'name' => $name];
    echo ($ok ? 'PASS ' : 'FAIL ') . $name . "\n";
}
foreach (['https://learn.example','https://learn.example/academy','https://courses.example:8443/team/skills/','http://127.0.0.1:9080/a/b','https://learn.example/admin','https://learn.example/assets','https://learn.example/api','https://learn.example/learning%20space','https://learn.example/学习'] as $base) {
    putenv('APP_URL=' . $base);
    $canonical = rtrim($base, '/');
    if (str_contains($base, '学习')) {
        $canonical = str_replace('学习', rawurlencode('学习'), $canonical);
    }
    $prefix = parse_url($canonical, PHP_URL_PATH) ?: '';
    $_SERVER['REQUEST_URI'] = $prefix . '/paths?filter=active&page=1';
    $samples = [
        ['route','/',$canonical . '/'],
        ['route','/login',$canonical . '/login'],
        ['route','register',$canonical . '/register'],
        ['route','/admin',$canonical . '/admin'],
        ['route','/api/auth/register',$canonical . '/api/auth/register'],
        ['to',$canonical . '/login?x=1#form',$canonical . '/login?x=1#form'],
        ['to',$prefix . '/login?x=1#form',$canonical . '/login?x=1#form'],
        ['to','?page=2',$canonical . '/paths?page=2'],
        ['to','#section',$canonical . '/paths?filter=active&page=1#section'],
        ['to','/paths?tag=a&tag=b',$canonical . '/paths?tag=a&tag=b'],
        ['route','//evil.example/',null],
        ['route','https://evil.example/login',null],
        ['route','javascript:alert(1)',null],
        ['route','/x/../login',null],
        ['route','/%2e%2e/.env',null],
        ['route','/a%2fb',null],
        ['route','/a%5cb',null],
        ['route',"/login\r\nInjected: x",null],
    ];
    foreach ($samples as [$method,$ref,$expected]) {
        try {
            $actual = Url::$method($ref);
            $ok = $actual === $expected;
        } catch (InvalidArgumentException $e) {
            $actual = null;
            $ok = $expected === null;
        }
        verifyUrl($ok, "$method reference on $base: " . json_encode($ref));
        $cases[] = ['base' => $base,'current' => $_SERVER['REQUEST_URI'],'method' => $method,'reference' => $ref,'expected' => $expected];
    }
    $actual = Url::route('/paths?tag=a&tag=b&page=1', ['page' => 2,'q' => 'a & b','filters' => ['web','design']], 'Chapter 1');
    $expected = $canonical . '/paths?tag=a&tag=b&page=2&q=a%20%26%20b&filters%5B0%5D=web&filters%5B1%5D=design#Chapter%201';
    verifyUrl($actual === $expected, 'Query merge, repeated keys, arrays and fragments on ' . $base);
    $cases[] = ['base' => $base,'current' => $_SERVER['REQUEST_URI'],'method' => 'route','reference' => '/paths?tag=a&tag=b&page=1','query' => ['page' => 2,'q' => 'a & b','filters' => ['web','design']],'fragment' => 'Chapter 1','expected' => $expected];
    verifyUrl(Url::asset('css/main.css') === $canonical . '/assets/css/main.css', 'Asset URL on ' . $base);
    $cases[] = ['base' => $base,'current' => $_SERVER['REQUEST_URI'],'method' => 'asset','reference' => 'css/main.css','expected' => $canonical . '/assets/css/main.css'];
    verifyUrl(Url::routePath($prefix . '/api/auth/register?x=1') === '/api/auth/register', 'Route/query normalisation on ' . $base);
    verifyUrl(Url::routePath($prefix ?: '/') === '/' && Url::routePath($prefix . '/') === '/', 'Both base-root slash forms on ' . $base);
    if ($prefix) {
        verifyUrl(Url::routePath('/outside') === null && Url::routePath($prefix . '-different/login') === null, 'Mount boundary prevents false matches on ' . $base);
    }
    verifyUrl(Url::routePath($prefix . '/%2e%2e/.env') === null, 'Traversal request rejected on ' . $base);
}
$invalidBases = ['','learn.example','ftp://learn.example','//learn.example','https://user:pass@learn.example','https://learn.example?x=1','https://learn.example/#x','https://learn.example/a/../b','https://learn.example/a%2fb','https://learn.example/a%5cb',"https://learn.example/\r\n",'https://learn.example:99999','https://bad host.example'];
file_put_contents(__DIR__ . '/refactor/url-invalid-bases.json', json_encode($invalidBases));
foreach ($invalidBases as $bad) {
    putenv('APP_URL=' . $bad);
    $rejected = false;
    try {
        Url::base();
    } catch (Throwable) {
        $rejected = true;
    }verifyUrl($rejected, 'Invalid base rejected: ' . json_encode($bad));
}
$original === false ? putenv('APP_URL') : putenv('APP_URL=' . $original);
unset($_SERVER['REQUEST_URI']);
file_put_contents(__DIR__ . '/refactor/url-cases.json', json_encode($cases, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
file_put_contents(__DIR__ . '/refactor/url-php-results.json', json_encode($checks, JSON_PRETTY_PRINT));
$passed = count(array_filter($checks, fn($c)=>$c['passed']));
echo "\n$passed passed; " . (count($checks) - $passed) . " failed.\n";
exit($passed === count($checks) ? 0 : 1);
