"""Static regressions for URL bypasses. Logical route definitions/payloads are not URLs.
CSS/ES-module relatives inherit centrally generated parent asset URLs.
External content links, fragments and filesystem paths are intentionally not prefixed.
"""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(ok,name,details=None):
    checks.append({'passed':bool(ok),'name':name,'details':details or []})
    print(('PASS ' if ok else 'FAIL ')+name)
files=[p for folder in ['app','config','routes','bin','public'] for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ['.php','.js','.css','.sh']]
bad=[]
for p in files:
    s=p.read_text()
    if p.suffix=='.php':
        for m in re.finditer(r'\b(?:href|src|action|data-api-button|data-private-notes)=["\']/[^/]',s):bad.append(str(p.relative_to(ROOT))+':'+m.group())
check(not bad,'No raw root-relative rendered links, asset attributes, HTTP form actions or endpoint attributes',bad)
bad=[]
for p in (ROOT/'public/assets/css').glob('*.css'):
    if re.search(r'\burl\(\s*["\']?/',p.read_text()):bad.append(str(p.relative_to(ROOT)))
check(not bad,'Stylesheets have no root-relative URL dependencies',bad)
bad=[]
for p in files:
    if p.name=='Url.php' or p.suffix!='.php':continue
    if re.search(r"env\(\s*['\"]APP_URL['\"]",p.read_text()):bad.append(str(p.relative_to(ROOT)))
check(not bad,'No independent PHP URL concatenation reads APP_URL outside the central service',bad)
bad=[]
for p in files:
    if re.search(r'https?://[^\s\'"<>]*\.e2b\.app|/home/user|localhost:8080|127\.0\.0\.1:8080',p.read_text()):bad.append(str(p.relative_to(ROOT)))
check(not bad,'Application logic contains no preview domain, workspace path or preview origin',bad)
s=(ROOT/'public/assets/js/api.js').read_text();check(bool(re.search(r'fetch\(\s*routeUrl\(',s)),'The shared fetch wrapper resolves through the APP_URL client service')
check('appUrl(data.redirect)' in s,'Client response redirects are validated centrally')
check("'Location: ' . route_url($path)" in (ROOT/'app/Helpers/functions.php').read_text(),'Server Location headers are generated centrally')
check('Url::routePath(' in (ROOT/'public/index.php').read_text(),'Front controller normalises the configured mount before dispatch')
check('Url::basePath()' in (ROOT/'app/Middleware/Security.php').read_text(),'Authentication/CSRF cookie paths follow the configured mount')
check('route_url($m[\'link\'])' in (ROOT/'app/Services/JobService.php').read_text(),'Queued notification links resolve at actual delivery time')
for filename in ['.htaccess','public/.htaccess']:
    s=(ROOT/filename).read_text();check(not re.search(r'^\s*(?:Options|php_value|php_flag|RewriteBase)\s',s,re.M),filename+' uses no host-dependent Options/php_value/RewriteBase directive')
report={'files_scanned':len(files),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'checks':checks}
(ROOT/'tests/refactor/source-audit.json').write_text(json.dumps(report,indent=2))
print(f"\nScanned {len(files)} source files. {report['passed']} passed; {report['failed']} failed.")
raise SystemExit(1 if report['failed'] else 0)
