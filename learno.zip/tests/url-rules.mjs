import { readFileSync, writeFileSync } from 'node:fs';
import { createUrlTools } from '../public/assets/js/url.js';
const cases=JSON.parse(readFileSync(new URL('./refactor/url-cases.json',import.meta.url)));
const checks=[];
for (const c of cases) {
  let actual=null;
  try {const u=createUrlTools(c.base,c.current);actual=u[c.method](c.reference,c.query||{},c.fragment??null);}catch{}
  const passed=actual===c.expected;
  checks.push({passed,name:`${c.method}: ${c.base} + ${c.reference}`,expected:c.expected,actual});
  console.log(`${passed?'PASS':'FAIL'} ${checks.at(-1).name}`);
}
for (const base of JSON.parse(readFileSync(new URL('./refactor/url-invalid-bases.json',import.meta.url)))) {
  let passed=false;try{createUrlTools(base);}catch{passed=true;}checks.push({passed,name:'Invalid base rejected: '+base});console.log(`${passed?'PASS':'FAIL'} Invalid base rejected: ${base}`);
}
writeFileSync(new URL('./refactor/url-js-results.json',import.meta.url),JSON.stringify(checks,null,2));
console.log(`\n${checks.filter(c=>c.passed).length} passed; ${checks.filter(c=>!c.passed).length} failed.`);
process.exitCode=checks.some(c=>!c.passed)?1:0;
